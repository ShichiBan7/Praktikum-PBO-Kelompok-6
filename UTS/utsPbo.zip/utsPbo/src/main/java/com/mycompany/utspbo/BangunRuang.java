/**
 *
 * @author Naufal Huseini
 */
package com.mycompany.utspbo;

import java.util.Scanner;

public class BangunRuang {
    final static double PI = 22.0 / 7;
    double sisi;
    double jariJari;
    double sisiAlas;
    double tinggi;
    
    public static int i = 0;
    public static double[] riwayatVolume = new double[10];
    public static double[] riwayatLuas = new double[10];
    
    public static double volume(double sisi){
        double volumeKubus = sisi * sisi * sisi;
        System.out.println("Volume dari kubus adalah : " + volumeKubus + "cm^3");
        riwayatVolume[i] = volumeKubus;
        return volumeKubus;
    }
    
    public static double volume(double PI, double jariJari){
        double volumeBola = PI * jariJari * jariJari * jariJari * 4 / 3;
        System.out.println("Volume dari bola adalah : " + volumeBola + "cm^3");
        riwayatVolume[i] = volumeBola;
        return volumeBola;
    }
    
    public static double volume(double sisi, double sisiAlas, double tinggi){
        double volumeLimas = (sisi * sisi) * tinggi / 3;
        System.out.println("Volume dari limas adalah : " + volumeLimas + "cm^3");
        riwayatVolume[i] = volumeLimas;
        return volumeLimas;
    }
    
    public static double luasPermukaan(double sisi){
        double permukaanKubus = 6 * sisi * sisi;
        System.out.println("Luas permukaan dari kubus adalah : " + permukaanKubus + "cm^3");
        riwayatLuas[i] = permukaanKubus;
        return permukaanKubus;
    }
    
    public static double luasPermukaan(double PI, double jariJari){
        double permukaanBola = 4 * PI * jariJari * jariJari;
        System.out.println("Luas permukaan dari bola adalah : " + permukaanBola + "cm^3");
        riwayatLuas[i] = permukaanBola;
        return permukaanBola;
    }
    
    public static double luasPermukaan(double sisi, double sisiAlas, double tinggi){
        double permukaanLimas = (sisi * sisi) + 4 * (sisiAlas * tinggi / 2);
        System.out.println("Luas permukaan dari bola adalah : " + permukaanLimas + "cm^3");
        riwayatLuas[i] = permukaanLimas;
        return permukaanLimas;
    }
    
        public static void main(String[] args){
        Scanner input = new Scanner(System.in); 
        String pilih;
        System.out.println("Kalkulator Volume dan Luas Permukaan Bangun Ruang");
        System.out.println("1. Kubus");
        System.out.println("2. Bola");
        System.out.println("3. Limas Segilima");
        System.out.println("4. Rekap Perhitungan");
        System.out.println("5. Keluar");
        do{
            System.out.println("===============================");
            System.out.print("Pilihan anda (1-5) : ");
            pilih = input.next();
            switch(pilih){
                case "1":
                    System.out.println("Menghitung Volume & Luas Permukaan Kubus");
                    System.out.print("Masukkan panjang sisi (cm): ");
                    double sisi = input.nextDouble();
                    if(sisi < 0){
                        System.out.println("Nilai tidak boleh negatif!");
                        break;
                    }
                    volume(sisi);
                    luasPermukaan(sisi);
                    i++;
                    break;
                case "2":
                    System.out.println("Menghitung Volume & Luas Permukaan Bola");
                    System.out.print("Masukkan panjang jari-jari (cm): ");
                    double jariJari = input.nextDouble();
                    if(jariJari < 0){
                        System.out.println("Nilai tidak boleh negatif!");
                        break;
                    }
                    volume(PI, jariJari);
                    luasPermukaan(PI, jariJari);
                    i++;
                    break;
                case "3":
                    System.out.println("Menghitung Volume & Luas Permukaan Limas Segilima");
                    System.out.print("Masukkan panjang sisi limas (cm): ");
                    sisi = input.nextDouble();
                    if(sisi < 0){
                        System.out.println("Nilai tidak boleh negatif!");
                        break;
                    }
                    System.out.print("Masukkan panjang alas limas (cm): ");
                    double sisiAlas = input.nextDouble();
                    if(sisiAlas < 0){
                        System.out.println("Nilai tidak boleh negatif!");
                        break;
                    }
                    System.out.print("Masukkan tinggi limas (cm): ");
                    double tinggi = input.nextDouble();
                    if(tinggi < 0){
                        System.out.println("Nilai tidak boleh negatif!");
                        break;
                    }
                    volume(sisi, sisiAlas, tinggi);
                    luasPermukaan(sisi, sisiAlas, tinggi);
                    i++;
                    break;
                case "4":
                    System.out.println("Rekap hasil penggunaan kalkulator");
                    System.out.println("Rekap hasil volume");
                    for(int j = 0; j < i; j++){
                        System.out.println(riwayatVolume[j]);
                    }
                    System.out.println("Rekap hasil luas permukaan");
                                        for(int j = 0; j < i; j++){
                        System.out.println(riwayatLuas[j]);
                    }
                    break;
                case "5": 
                    System.out.println("Terimakasih sudah menggunakan kalkulator");
                    break;
                default:
                    System.out.println("Input tidak valid!");
            }
        }while(!"5".equals(pilih));
    }
}
