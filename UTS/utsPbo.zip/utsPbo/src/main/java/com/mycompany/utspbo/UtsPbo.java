/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.utspbo;

/**
 *
 * @author ASUS
 */
public class UtsPbo {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
