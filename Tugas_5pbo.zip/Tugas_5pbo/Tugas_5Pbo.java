/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tugas_5pbo;

/**
 *
 * @author Herva Sulistia
 */
public class Tugas_5Pbo {

    public static void main(String[] args) {
        
        Sepatu sepatu1 = new Sepatu("Converse", 42, "Hitam"); 
        Sepatu sepatu2 = new Sepatu("Nike Air Jordan", 40);
        Sepatu sepatu3 = new Sepatu();
        
        // Menampilkan info ketiga sepatu
        System.out.println("======== Sepatu 1 ========");
        sepatu1.tampilkanInfo();

        System.out.println("======== Sepatu 2 ========");
        sepatu2.tampilkanInfo();

        System.out.println("======== Sepatu 3 ========");
        sepatu3.tampilkanInfo();
        
        System.out.println();
        
        sepatu1.ubahWarna("Putih");
        sepatu1.tampilkanInfo();

        System.out.println();
        
        sepatu2.ubahWarna(1); 
        sepatu2.tampilkanInfo();

        System.out.println();
        
        sepatu3.ubahWarna(7); 
        sepatu3.tampilkanInfo();
    }
}
