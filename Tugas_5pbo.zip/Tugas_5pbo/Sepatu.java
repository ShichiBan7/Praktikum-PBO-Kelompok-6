/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tugas_5pbo;

/**
 *
 * @author Herva Sulistia
 */
public class Sepatu {
    String merk;
    int ukuran;
    String warna;
    
      public Sepatu() {
        this.merk = "Secret";
        this.ukuran = 0;
        this.warna = "Secret";
    }  
        
    public Sepatu(String merk, int ukuran, String warna) {
        this.merk = merk;
        this.ukuran = ukuran;
        this.warna = warna; 
    }
    
    public Sepatu(String merk, int ukuran) {
        this.merk = merk;
        this.ukuran = ukuran;
        this.warna = "Tidak diketahui";
    }    
   
    
   public void tampilkanInfo() {
        System.out.println("Merk   : " + merk);
        System.out.println("Ukuran : " + ukuran);
        System.out.println("Warna  : " + warna);
}
   
   public void ubahWarna(String warnaBaru) {
        this.warna = warnaBaru;
        System.out.println("Warna sepatu diubah menjadi: " + warna);
    }
   
   public void ubahWarna(int kodeWarna) {
        if (kodeWarna == 1) {
            this.warna = "Hitam";
            
        } else if (kodeWarna == 2) {
            this.warna = "Putih";
            
        } else {
            this.warna = "Secret";
        }
        System.out.println("Warna sepatu diubah menjadi: " + warna);
    }
}