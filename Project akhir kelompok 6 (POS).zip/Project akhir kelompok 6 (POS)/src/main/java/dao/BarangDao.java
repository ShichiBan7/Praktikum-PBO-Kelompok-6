package dao;

import config.Koneksi;
import model.Barang;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BarangDao {
    public List<Barang> getAll() throws SQLException {
        List<Barang> list = new ArrayList<>();
        String sql = "SELECT * FROM barang";
        try (Connection c = Koneksi.getConnection(); PreparedStatement p = c.prepareStatement(sql); ResultSet r = p.executeQuery()) {
            while (r.next()) {
                Barang b = new Barang(r.getInt("id_barang"), r.getString("nama_barang"), r.getInt("harga"), r.getInt("stok"));
                list.add(b);
            }
        }
        return list;
    }

    public void insert(Barang b) throws SQLException {
        String sql = "INSERT INTO barang (nama_barang, harga, stok) VALUES (?,?,?)";
        try (Connection c = Koneksi.getConnection(); PreparedStatement p = c.prepareStatement(sql)) {
            p.setString(1, b.getNama()); p.setInt(2, b.getHarga()); p.setInt(3, b.getStok());
            p.executeUpdate();
        }
    }

    public void update(Barang b) throws SQLException {
        String sql = "UPDATE barang SET nama_barang=?, harga=?, stok=? WHERE id_barang=?";
        try (Connection c = Koneksi.getConnection(); PreparedStatement p = c.prepareStatement(sql)) {
            p.setString(1, b.getNama()); p.setInt(2, b.getHarga()); p.setInt(3, b.getStok()); p.setInt(4, b.getId());
            p.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM barang WHERE id_barang=?";
        try (Connection c = Koneksi.getConnection(); PreparedStatement p = c.prepareStatement(sql)) {
            p.setInt(1, id); p.executeUpdate();
        }
    }

    public Barang findById(int id) throws SQLException {
        String sql = "SELECT * FROM barang WHERE id_barang=?";
        try (Connection c = Koneksi.getConnection(); PreparedStatement p = c.prepareStatement(sql)) {
            p.setInt(1, id);
            try (ResultSet r = p.executeQuery()) {
                if (r.next()) return new Barang(r.getInt("id_barang"), r.getString("nama_barang"), r.getInt("harga"), r.getInt("stok"));
            }
        }
        return null;
    }

    public List<Barang> searchByName(String keyword) throws SQLException {
        List<Barang> list = new ArrayList<>();
        String sql = "SELECT * FROM barang WHERE nama_barang LIKE ?";
        try (Connection c = Koneksi.getConnection(); PreparedStatement p = c.prepareStatement(sql)) {
            p.setString(1, "%"+keyword+"%");
            try (ResultSet r = p.executeQuery()) {
                while (r.next()) list.add(new Barang(r.getInt("id_barang"), r.getString("nama_barang"), r.getInt("harga"), r.getInt("stok")));
            }
        }
        return list;
    }
}
