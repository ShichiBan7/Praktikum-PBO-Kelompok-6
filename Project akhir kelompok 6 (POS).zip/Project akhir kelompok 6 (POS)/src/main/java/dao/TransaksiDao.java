package dao;

import config.Koneksi;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class TransaksiDao {

    public String generateId() throws SQLException {
        String date = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        return "TRX" + date;
    }

    public void saveTransaksi(String id, int total, int bayar, int kembalian, List<Object[]> detail, Integer idMember) throws SQLException {
        String sqlTrans = "INSERT INTO transaksi (id_transaksi, tanggal, total, bayar, kembalian) VALUES (?,?,?,?,?)";
        String sqlDetail = "INSERT INTO detail_transaksi (id_transaksi, id_barang, qty, subtotal) VALUES (?,?,?,?)";
        String sqlUpdateStock = "UPDATE barang SET stok = stok - ? WHERE id_barang = ?";
        String sqlInsertStockHistory = "INSERT INTO stock_history (id_barang, perubahan, keterangan) VALUES (?,?,?)";
        String sqlUpdateMemberPoin = "UPDATE member SET poin = poin + ? WHERE id_member = ?";

        Connection c = null;
        try {
            c = Koneksi.getConnection();
            c.setAutoCommit(false);

            // Insert transaksi utama
            try (PreparedStatement p = c.prepareStatement(sqlTrans)) {
                p.setString(1, id);
                p.setTimestamp(2, new Timestamp(System.currentTimeMillis())); // waktu lokal
                p.setInt(3, total);
                p.setInt(4, bayar);
                p.setInt(5, kembalian);
                p.executeUpdate();
            }

            // Insert detail dan update stok
            try (PreparedStatement p2 = c.prepareStatement(sqlDetail);
                 PreparedStatement pUpdateStock = c.prepareStatement(sqlUpdateStock);
                 PreparedStatement pStockHist = c.prepareStatement(sqlInsertStockHistory)) {

                for (Object[] row : detail) {
                    int idBarang = (Integer) row[0];
                    int qty = (Integer) row[1];
                    int subtotal = (Integer) row[2];

                    // detail transaksi
                    p2.setString(1, id);
                    p2.setInt(2, idBarang);
                    p2.setInt(3, qty);
                    p2.setInt(4, subtotal);
                    p2.addBatch();

                    // update stok
                    pUpdateStock.setInt(1, qty);
                    pUpdateStock.setInt(2, idBarang);
                    pUpdateStock.addBatch();

                    // stock history
                    pStockHist.setInt(1, idBarang);
                    pStockHist.setInt(2, -qty);
                    pStockHist.setString(3, "Penjualan " + id);
                    pStockHist.addBatch();
                }

                p2.executeBatch();
                pUpdateStock.executeBatch();
                pStockHist.executeBatch();
            }

            // update poin member
            if (idMember != null) {
                int poinEarned = total / 10000;
                try (PreparedStatement p = c.prepareStatement(sqlUpdateMemberPoin)) {
                    p.setInt(1, poinEarned);
                    p.setInt(2, idMember);
                    p.executeUpdate();
                }
            }

            c.commit();
        } catch (SQLException ex) {
            if (c != null) c.rollback();
            throw ex;
        } finally {
            if (c != null) {
                c.setAutoCommit(true);
                c.close();
            }
        }
    }

    // Method untuk load semua transaksi beserta tanggal
    public ResultSet getAllTransaksi() throws SQLException {
        String sql = "SELECT id_transaksi, tanggal, total, bayar, kembalian FROM transaksi ORDER BY tanggal DESC";
        return Koneksi.getConnection().createStatement().executeQuery(sql);
    }
}
