package ui;

import dao.TransaksiDao;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.FileOutputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.awt.Desktop;
import java.util.Date;

public class FormLaporan extends JPanel {

    private JTable table;
    private DefaultTableModel model;
    private JButton btnRefresh, btnExportPDF, btnExportExcel;
    private JComboBox<String> cmbFilter; // filter hari/bulan
    private TransaksiDao trxDao = new TransaksiDao();

    public FormLaporan() {
        setLayout(new BorderLayout());

        model = new DefaultTableModel(new Object[]{
                "ID Transaksi", "Tanggal", "Total", "Bayar", "Kembalian"
        }, 0);

        table = new JTable(model);

        // TOP PANEL: tombol + filter
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnRefresh = new JButton("Refresh");
        btnExportPDF = new JButton("Export PDF");
        btnExportExcel = new JButton("Export Excel");

        cmbFilter = new JComboBox<>(new String[]{"Semua", "Hari Ini", "Bulan Ini"});
        top.add(new JLabel("Filter:")); top.add(cmbFilter);
        top.add(btnRefresh);
        top.add(btnExportPDF);
        top.add(btnExportExcel);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        loadData("Semua");
        attachListeners();
    }

    private void loadData(String filter) {
        try {
            model.setRowCount(0);
            ResultSet rs = trxDao.getAllTransaksi();
            Timestamp now = new Timestamp(System.currentTimeMillis());
            SimpleDateFormat sdfDay = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat sdfMonth = new SimpleDateFormat("yyyy-MM");

            while (rs.next()) {
                Timestamp ts = rs.getTimestamp("tanggal");
                String tglStr = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(ts);

                boolean include = false;
                if (filter.equals("Semua")) {
                    include = true;
                } else if (filter.equals("Hari Ini")) {
                    include = sdfDay.format(ts).equals(sdfDay.format(now));
                } else if (filter.equals("Bulan Ini")) {
                    include = sdfMonth.format(ts).equals(sdfMonth.format(now));
                }

                if (include) {
                    model.addRow(new Object[]{
                            rs.getString("id_transaksi"),
                            tglStr,
                            rs.getInt("total"),
                            rs.getInt("bayar"),
                            rs.getInt("kembalian")
                    });
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Load laporan gagal: " + e.getMessage());
        }
    }

    private void attachListeners() {
        btnRefresh.addActionListener(e -> loadData(cmbFilter.getSelectedItem().toString()));
        cmbFilter.addActionListener(e -> loadData(cmbFilter.getSelectedItem().toString()));
        btnExportExcel.addActionListener(e -> exportExcelX());
        btnExportPDF.addActionListener(e -> exportPDF());
    }

    private void exportExcelX() {
        try {
            String fileName = "laporan_penjualan.xlsx";
            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("Laporan Penjualan");

            CellStyle headerStyle = workbook.createCellStyle();
            org.apache.poi.ss.usermodel.Font font = workbook.createFont();
            font.setBold(true);
            headerStyle.setFont(font);

            Row header = sheet.createRow(0);
            String[] columns = {"ID Transaksi", "Tanggal", "Total", "Bayar", "Kembalian"};
            for (int i = 0; i < columns.length; i++) {
                Cell cell = header.createCell(i);
                cell.setCellValue(columns[i]);
                cell.setCellStyle(headerStyle);
            }

            for (int i = 0; i < model.getRowCount(); i++) {
                Row row = sheet.createRow(i + 1);
                for (int j = 0; j < columns.length; j++) {
                    Object val = model.getValueAt(i, j);
                    if (val instanceof Integer) {
                        row.createCell(j).setCellValue((Integer) val);
                    } else {
                        row.createCell(j).setCellValue(val.toString());
                    }
                }
            }

            for (int i = 0; i < columns.length; i++) sheet.autoSizeColumn(i);

            FileOutputStream fos = new FileOutputStream(fileName);
            workbook.write(fos);
            fos.close();
            workbook.close();

            JOptionPane.showMessageDialog(this, "Export Excel (.xlsx) berhasil!");
            if (Desktop.isDesktopSupported()) Desktop.getDesktop().open(new java.io.File(fileName));

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Export gagal: " + e.getMessage());
        }
    }

    private void exportPDF() {
        String fileName = "laporan_penjualan.pdf";
        Document document = new Document();

        try {
            PdfWriter.getInstance(document, new FileOutputStream(fileName));
            document.open();

            document.add(new Paragraph("=== LAPORAN PENJUALAN ===\n\n"));

            PdfPTable pdfTable = new PdfPTable(model.getColumnCount());
            for (int i = 0; i < model.getColumnCount(); i++) pdfTable.addCell(model.getColumnName(i));
            for (int r = 0; r < model.getRowCount(); r++)
                for (int c = 0; c < model.getColumnCount(); c++)
                    pdfTable.addCell(model.getValueAt(r, c).toString());

            document.add(pdfTable);
            document.close();

            JOptionPane.showMessageDialog(this, "PDF berhasil dibuat!");
            Desktop.getDesktop().open(new java.io.File(fileName));

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Export PDF gagal: " + e.getMessage());
        }
    }
}
