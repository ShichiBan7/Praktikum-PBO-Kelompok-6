package ui;

import dao.BarangDao;
import dao.TransaksiDao;
import model.Barang;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;

public class FormTransaksi extends JPanel {

    private BarangDao barangDao = new BarangDao();
    private TransaksiDao trxDao = new TransaksiDao();

    private JTable tableBarang, tableCart;
    private DefaultTableModel modelBarang, modelCart;
    private JTextField txtCari, txtQty, txtTotal, txtBayar, txtKembali;
    private JButton btnAddToCart, btnRemoveCart, btnBayar, btnRefresh;

    public FormTransaksi() {
        setLayout(new BorderLayout());

        modelBarang = new DefaultTableModel(new Object[]{"ID", "Nama", "Harga", "Stok"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        modelCart = new DefaultTableModel(new Object[]{"ID", "Nama", "Harga", "Qty", "Subtotal"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        tableBarang = new JTable(modelBarang);
        tableCart = new JTable(modelCart);

        // LEFT PANEL
        JPanel left = new JPanel(new BorderLayout());
        JPanel topLeft = new JPanel(new FlowLayout(FlowLayout.LEFT));
        txtCari = new JTextField(15);
        btnRefresh = new JButton("Refresh");
        topLeft.add(new JLabel("Cari:"));
        topLeft.add(txtCari);
        topLeft.add(btnRefresh);
        left.add(topLeft, BorderLayout.NORTH);
        left.add(new JScrollPane(tableBarang), BorderLayout.CENTER);

        // CENTER PANEL
        JPanel center = new JPanel(new BorderLayout());
        JPanel addPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        txtQty = new JTextField(5);
        btnAddToCart = new JButton("Tambah ke Keranjang");
        addPanel.add(new JLabel("Qty:"));
        addPanel.add(txtQty);
        addPanel.add(btnAddToCart);
        center.add(addPanel, BorderLayout.NORTH);
        center.add(new JScrollPane(tableCart), BorderLayout.CENTER);

        // RIGHT PANEL
        JPanel right = new JPanel(new GridLayout(6, 1, 5, 5));
        txtTotal = new JTextField(); txtTotal.setEditable(false);
        txtBayar = new JTextField();
        txtKembali = new JTextField(); txtKembali.setEditable(false);

        btnRemoveCart = new JButton("Hapus Item");
        btnBayar = new JButton("Bayar");

        right.add(new JLabel("Total:")); right.add(txtTotal);
        right.add(new JLabel("Bayar:")); right.add(txtBayar);
        right.add(new JLabel("Kembalian:")); right.add(txtKembali);

        JPanel bottomButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomButtons.add(btnRemoveCart); bottomButtons.add(btnBayar);

        add(left, BorderLayout.WEST);
        add(center, BorderLayout.CENTER);
        add(right, BorderLayout.EAST);
        add(bottomButtons, BorderLayout.SOUTH);

        loadBarang();
        attachListeners();
    }

    private void loadBarang() {
        try {
            modelBarang.setRowCount(0);
            List<Barang> list = barangDao.getAll();
            for (Barang b : list) {
                modelBarang.addRow(new Object[]{b.getId(), b.getNama(), b.getHarga(), b.getStok()});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error load barang: " + e.getMessage());
        }
    }

    private void filterBarang(String key) {
        try {
            key = key.toLowerCase().trim();
            modelBarang.setRowCount(0);
            List<Barang> list = barangDao.getAll();
            for (Barang b : list) {
                if (b.getNama().toLowerCase().contains(key)) {
                    modelBarang.addRow(new Object[]{b.getId(), b.getNama(), b.getHarga(), b.getStok()});
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error filter barang: " + e.getMessage());
        }
    }

    private void attachListeners() {

        btnRefresh.addActionListener(e -> loadBarang());

        // Live search
        txtCari.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            private void search() { filterBarang(txtCari.getText()); }
            @Override public void insertUpdate(javax.swing.event.DocumentEvent e) { search(); }
            @Override public void removeUpdate(javax.swing.event.DocumentEvent e) { search(); }
            @Override public void changedUpdate(javax.swing.event.DocumentEvent e) { search(); }
        });

        btnAddToCart.addActionListener(e -> {
            int r = tableBarang.getSelectedRow();
            if (r == -1) { JOptionPane.showMessageDialog(this, "Pilih barang dulu!"); return; }
            try {
                int id = Integer.parseInt(modelBarang.getValueAt(r, 0).toString());
                String nama = modelBarang.getValueAt(r, 1).toString();
                int harga = Integer.parseInt(modelBarang.getValueAt(r, 2).toString());
                int stok = Integer.parseInt(modelBarang.getValueAt(r, 3).toString());
                int qty = Integer.parseInt(txtQty.getText());

                if (qty <= 0 || qty > stok) {
                    JOptionPane.showMessageDialog(this, "Qty tidak valid / melebihi stok!");
                    return;
                }

                int subtotal = harga * qty;
                modelCart.addRow(new Object[]{id, nama, harga, qty, subtotal});
                updateTotal();
                txtQty.setText(""); // reset

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error add cart: " + ex.getMessage());
            }
        });

        btnRemoveCart.addActionListener(e -> {
            int r = tableCart.getSelectedRow();
            if (r == -1) { JOptionPane.showMessageDialog(this, "Pilih item di keranjang!"); return; }
            modelCart.removeRow(r);
            updateTotal();
        });

        btnBayar.addActionListener(e -> {
            try {
                int rowCount = modelCart.getRowCount();
                if (rowCount == 0) { JOptionPane.showMessageDialog(this, "Keranjang masih kosong!"); return; }

                int total = Integer.parseInt(txtTotal.getText());
                int bayar = Integer.parseInt(txtBayar.getText());
                if (bayar < total) { JOptionPane.showMessageDialog(this, "Uang bayar kurang!"); return; }

                int kembalian = bayar - total;
                txtKembali.setText(String.valueOf(kembalian));

                List<Object[]> detail = new ArrayList<>();
                for (int i = 0; i < rowCount; i++) {
                    int idBarang = Integer.parseInt(modelCart.getValueAt(i, 0).toString());
                    int qty = Integer.parseInt(modelCart.getValueAt(i, 3).toString());
                    int subtotal = Integer.parseInt(modelCart.getValueAt(i, 4).toString());
                    detail.add(new Object[]{idBarang, qty, subtotal});
                }

                String idTrx = trxDao.generateId();
                trxDao.saveTransaksi(idTrx, total, bayar, kembalian, detail, null);

                JOptionPane.showMessageDialog(this,
                        "Transaksi berhasil!\nID: " + idTrx + "\nKembalian: " + kembalian);

                int pilih = JOptionPane.showConfirmDialog(this,
                        "Apakah ingin mencetak struk transaksi?", "Cetak Struk", JOptionPane.YES_NO_OPTION);

                if (pilih == JOptionPane.YES_OPTION) generateStrukPDF(idTrx, total, bayar, kembalian);

                // reset form
                modelCart.setRowCount(0); txtBayar.setText(""); txtTotal.setText("0");
                txtKembali.setText(""); txtQty.setText(""); loadBarang();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Gagal transaksi: " + ex.getMessage());
            }
        });
    }

    private void updateTotal() {
        int sum = 0;
        for (int i = 0; i < modelCart.getRowCount(); i++)
            sum += Integer.parseInt(modelCart.getValueAt(i, 4).toString());
        txtTotal.setText(String.valueOf(sum));
    }

    private void generateStrukPDF(String idTrx, int total, int bayar, int kembalian) {
        try {
            String fileName = "struk_" + idTrx + ".pdf";
            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream(fileName));
            document.open();

            Font bold = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD);
            Paragraph title = new Paragraph("=== STRUK PENJUALAN ===", bold);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);
            document.add(new Paragraph("\nID Transaksi: " + idTrx + "\n"));

            PdfPTable table = new PdfPTable(4);
            table.setWidthPercentage(100);
            table.setWidths(new int[]{4, 2, 1, 2});
            table.addCell("Nama"); table.addCell("Harga"); table.addCell("Qty"); table.addCell("Subtotal");

            for (int i = 0; i < modelCart.getRowCount(); i++) {
                table.addCell(modelCart.getValueAt(i, 1).toString());
                table.addCell(modelCart.getValueAt(i, 2).toString());
                table.addCell(modelCart.getValueAt(i, 3).toString());
                table.addCell(modelCart.getValueAt(i, 4).toString());
            }

            document.add(table);
            document.add(new Paragraph("\nTotal: Rp" + total));
            document.add(new Paragraph("Bayar: Rp" + bayar));
            document.add(new Paragraph("Kembalian: Rp" + kembalian));

            document.close();

            if (Desktop.isDesktopSupported()) Desktop.getDesktop().open(new java.io.File(fileName));
            JOptionPane.showMessageDialog(this, "Struk PDF berhasil dibuat!");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal generate struk: " + e.getMessage());
        }
    }
}

