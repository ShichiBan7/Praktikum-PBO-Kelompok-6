package ui;

import dao.BarangDao;
import model.Barang;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.SQLException;
import java.util.List;

public class FormBarang extends JPanel {

    private BarangDao dao = new BarangDao();
    private JTable table;
    private DefaultTableModel model;
    private JTextField txtNama, txtHarga, txtStok, txtSearch;
    private JButton btnAdd, btnUpdate, btnDelete, btnSearch, btnRefresh;

    public FormBarang() {
        setLayout(new BorderLayout());
        model = new DefaultTableModel(new Object[]{"ID", "Nama", "Harga", "Stok"}, 0) {
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };
        table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        txtSearch = new JTextField(20);
//        btnSearch = new JButton("Cari");
        btnRefresh = new JButton("Refresh");
        top.add(new JLabel("Cari:"));
        top.add(txtSearch);
//        top.add(btnSearch);
        top.add(btnRefresh);

        JPanel form = new JPanel(new GridLayout(2, 4, 5, 5));
        txtNama = new JTextField();
        txtHarga = new JTextField();
        txtStok = new JTextField();
        btnAdd = new JButton("Tambah");
        btnUpdate = new JButton("Ubah");
        btnDelete = new JButton("Hapus");
        form.add(new JLabel("Nama"));
        form.add(txtNama);
        form.add(new JLabel("Harga"));
        form.add(txtHarga);
        form.add(new JLabel("Stok"));
        form.add(txtStok);
        form.add(btnAdd);
        form.add(btnUpdate);

        add(top, BorderLayout.NORTH);
        add(sp, BorderLayout.CENTER);
        add(form, BorderLayout.SOUTH);

        JPanel right = new JPanel(new BorderLayout());
        right.add(btnDelete, BorderLayout.NORTH);
        add(right, BorderLayout.EAST);

        loadTable();
        attachListeners();
    }

    private void loadTable() {
        try {
            model.setRowCount(0);
            List<Barang> list = dao.getAll();
            for (Barang b : list) {
                model.addRow(new Object[]{b.getId(), b.getNama(), b.getHarga(), b.getStok()});
            }
            clearForm();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void attachListeners() {
        // Tombol add
        btnAdd.addActionListener(e -> {
            try {
                Barang b = new Barang();
                b.setNama(txtNama.getText());
                b.setHarga(Integer.parseInt(txtHarga.getText()));
                b.setStok(Integer.parseInt(txtStok.getText()));
                dao.insert(b);
                loadTable();
                clearForm();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Gagal tambah: " + ex.getMessage());
            }
        });

        // Tombol update
        btnUpdate.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r == -1) {
                JOptionPane.showMessageDialog(this, "Pilih data di tabel");
                return;
            }
            try {
                int id = (Integer) model.getValueAt(r, 0);
                Barang b = new Barang();
                b.setId(id);
                b.setNama(txtNama.getText());
                b.setHarga(Integer.parseInt(txtHarga.getText()));
                b.setStok(Integer.parseInt(txtStok.getText()));
                dao.update(b);
                loadTable();
                clearForm();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Gagal update: " + ex.getMessage());
            }
        });

        // Tombol delete
        btnDelete.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r == -1) {
                JOptionPane.showMessageDialog(this, "Pilih data untuk dihapus");
                return;
            }
            int id = (Integer) model.getValueAt(r, 0);
            int ok = JOptionPane.showConfirmDialog(this, "Hapus ID " + id + "?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
            if (ok == JOptionPane.YES_OPTION) {
                try {
                    dao.delete(id);
                    loadTable();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(this, "Gagal hapus: " + ex.getMessage());
                }
            }
        });

        // Tombol refresh
        btnRefresh.addActionListener(e -> loadTable());

        // Live search (case-insensitive)
        txtSearch.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            private void search() {
                try {
                    String key = txtSearch.getText().trim().toLowerCase();
                    model.setRowCount(0);
                    List<Barang> list = dao.searchByName(key);
                    for (Barang b : list) {
                        model.addRow(new Object[]{b.getId(), b.getNama(), b.getHarga(), b.getStok()});
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(FormBarang.this, "Error: " + ex.getMessage());
                }
            }

            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                search();
            }

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                search();
            }

            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                search();
            }
        });

        // Pilih row di tabel, tampilkan di form
        table.getSelectionModel().addListSelectionListener(e -> {
            int r = table.getSelectedRow();
            if (r != -1) {
                txtNama.setText(String.valueOf(model.getValueAt(r, 1)));
                txtHarga.setText(String.valueOf(model.getValueAt(r, 2)));
                txtStok.setText(String.valueOf(model.getValueAt(r, 3)));
            }
        });
    }

    private void clearForm() {
        txtNama.setText("");
        txtHarga.setText("");
        txtStok.setText("");
    }
}
