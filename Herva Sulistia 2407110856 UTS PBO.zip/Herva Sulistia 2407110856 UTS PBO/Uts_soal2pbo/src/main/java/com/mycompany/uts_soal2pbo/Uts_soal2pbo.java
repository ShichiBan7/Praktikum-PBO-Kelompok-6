/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.uts_soal2pbo;

/**
 *
 * @author Herva Sulistia
 */
public class Uts_soal2pbo {

    public static void main(String[] args) {
         Scanner input = new Scanner(System.in);
   
    int pilihan;
        do {
           System.out.println("==== MENU VOLUME BANGUN RUANG ====");
           System.out.println("1.Kubus");
           System.out.println("2.Bola");
           System.out.println("3.Limas Segiempat");
           System.out.println("4.Rekap perhitungan");
           System.out.println("5.keluar");
           System.out.print("pilih (1-5):");
           pilihan = input.nextInt();
           
           switch (pilihan){
               case 1:
                   System.out.print("masukkan sisi: ");
                   double sisi = input.nextDouble();
                   double volumeKubus = sisi * sisi * sisi;
                   System.out.println("Volume kubus adalah " + volumeKubus);
                   break;
                   
               case 2:
                   System.out.print("masukkan  jari jari: ");
                   double jariJari=  input.nextDouble();
                   double volumeBola = 4/3 * PI * jariJari * jariJari * jariJari;
                   System.out.println("Volume Bola adalah " + volumeBola);
                   break;
                   
               case 3:
                   System.out.print("masukkan ");
                   double sisi = input.nextDouble();
                   System.out.print("masukkan tinggi segitiga");
                   double tinggi = input.nextDouble();
                   double volumeLse = 1/3 * sisi * sisi* tinggi;
                   System.out.println("Volume Limas Segiempat adalah " +volumeLse );
                   break;
                   
               case 4:
                   System.out.print("Rekap perhitungan");
                   
                           
               case 5:
                   System.out.println("====Terima kasih program selesai====");
                   break;
                   
                   
                   
               default :
                   System.out.println("pilihan tidak valid, silahkan coba lagi");
    }
}
