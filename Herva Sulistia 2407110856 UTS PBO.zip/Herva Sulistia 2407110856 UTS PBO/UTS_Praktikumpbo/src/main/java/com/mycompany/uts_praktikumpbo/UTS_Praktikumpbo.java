/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */


package com.mycompany.uts_praktikumpbo;
import java.util.Scanner;
/**
 *
 * @author Herva Sulistia
 */
public class UTS_Praktikumpbo {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
         enum Prodi {
             Teknik informatika,Teknik lingkungan
         }
             for (program p  : program.values()){
             
        int pilihan;
        do {
            System.out.println("====StudentApp==== ");
            System.out.println("1.Tampilkan Biodata ");
            System.out.println("2.Hitung umur akademik ");
            System.out.println("3.Keluar ");
            
        Switch (pilihan){
            case 1:
            System.out.print("masukkan nama")
        }   
            
       
            
        } 
        

    }
}






















