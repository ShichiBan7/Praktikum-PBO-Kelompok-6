/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_praktikumpbo;

/**
 *
 * @author Herva Sulistia
 */
public class Mahasiswa {
    String nama;
    int nim;
    String prodi;
    int tahunMasuk;
    
    public Mahasiswa(String nama, int nim, String prodi,int tahunMasuk){
        this.nama = nama;
        this.nim = nim;
        this.prodi = prodi;
        this.tahunMasuk = tahunMasuk;
    }
       
    public Mahasiswa(String nama,String prodi){
        this.nama = nama;
        this.nim = 0;
        this.prodi = prodi;
        this.tahunMasuk = 0;
    }  
    public void tampilkanInfo(){
    System.out.println("Nama: " + nama);
    System.out.println("Nim: " + nim);
    System.out.println("Program studi: " + prodi);
    System.out.println("Tahun masuk: " + tahunMasuk);    
    }
    
}

