/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.praktikum_9;

/**
 *
 * @author LENOVO
 */
public class Praktikum_9 {

    public static void main(String[] args) {
        
    }
}
