/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.praktikum_6;

/**
 *
 * @author LENOVO
 */
public class getHarga {

    private double harga;
    public double getHarga(double harga){
        return harga;
    }
    
    public void setHarga(double hargaBaru){
        if (hargaBaru>0) {
            this.harga = hargaBaru;
        }
        
        else if (hargaBaru == 0){
            this.harga = hargaBaru;
            System.out.println("Produk ini gratis.");
        }
        
        else {
            System.out.println("Harga produk tidak boleh negatif.");
        }
    }
}
