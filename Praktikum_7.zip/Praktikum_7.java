/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.praktikum_7;

/**
 *
 * @author Herva Sulistia
 */
public class Praktikum_7 {

    public static void main(String[] args) {
        Produk p1 = new Produk("Buku", 150000);
        BarangElektronik p2 = new BarangElektronik("Mouse", 150000, 12);
        
        p1.tampilkanInfo();
        System.out.println("Pajak Produk Umum : " + p1.hitungPajak());
        System.out.println("Hasil Akhir Produk : " + p1.hitungHarga());
        System.out.println("-----------------------");
        p2.tampilkanInfo();
        System.out.println("Pajak Barang Elektronik : " + p2.hitungPajak());
        System.out.println("Harga Akhir Produk  : " + p2.hitungHarga());
    }
}    
        
        
        
        
        
        
        
        
        
        
       // BarangElektronik p1 = new BarangElektronik("Laptop",500000,12);
       // p1.tampilkanInfo();
        //p1.tampilkanGaransi();
    

