/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.kuis2;

/**
 *
 * @author LENOVO
 */
public class Kuis2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
