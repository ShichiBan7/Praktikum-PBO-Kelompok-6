/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.kuis2;

/**
 *
 * @author LENOVO
 */
public class Hero extends Character{
    private String nama;
    private int hp;
    private int attackPower;
    private int defense;
    
    public Hero(String nama, int hp, int attackPower, int defense){
        this.nama = nama;
        this.hp = hp;
        this.attackPower = attackPower;
        this.defense = defense;
    }
    
    public String getNama(){
        return this.nama;
    }
    
    public int getHp(){
        return this.hp;
    }
    
    public int getAttackPower(){
        return this.attackPower;
    }
    
    public int getDefense(){
        return this.defense;
    }
    
    public void setNama(String nama){
        this.nama = nama;
    }
    
    public void setHp (int hp){
        this.hp = hp;
    }
    
    public void setAttackPower(int attackPower){
        this.attackPower = attackPower;
    }
    
    public void setDefense(int defense){
        this.defense = defense;
    }
    
    public void tampilkanInfo(){
        System.out.println("Nama Hero   : " + this.nama);
        System.out.println("Hp Hero    : " + this.hp);
        System.out.println("Attack Power : " + this.attackPower);
        System.out.println("Defense : " + this.defense);
        System.out.println();
    }
    
    public void attack(Enemy e){
        e.setHp(e.getHp() - this.attackPower);
        System.out.println(this.nama + " Menyerang " + e.getNama() + 
                " dengan power " + this.attackPower);
        System.out.println("Sisa hp " + e.getNama() + " : " + e.getHp());
        System.out.println();
    }
    
    public void useSkill(Enemy e){
        System.out.println(getNama() + " menggunakan skill serangan berturut-turut!");
        int damage = getAttackPower();
                
        for (int i = 1; i <= 2; i++) {
            
            e.setHp(e.getHp() - damage);
            System.out.println("Serangan ke-" + i + " memberikan damage " + damage);
            System.out.println("Sisa hp " + e.getNama() + " : " + e.getHp());
            damage *= 1.2; 
        }

        }
    
}
