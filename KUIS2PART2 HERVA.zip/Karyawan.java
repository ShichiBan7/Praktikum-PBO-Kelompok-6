/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.kuis_2;

/**
 *
 * @author LENOVO
 */
public class Karyawan {
    private String nama;
    private String NIP;
    
    public Karyawan(String nama, String NIP){
        this.nama = nama;
        this.NIP = NIP;
    }
    
    public String getNama(){
        return this.nama;
    }
    
    public String getNIP(){
        return this.NIP;
    }
    
    public void setNama(){
        this.nama = nama;
    }
    
    public void setNIP(){
        this.NIP = NIP;
    }
    
    public void tampilkanInfo(){
        System.out.println("");
    }
}
