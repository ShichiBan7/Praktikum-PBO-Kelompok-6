/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.kuis_2;

/**
 *
 * @author LENOVO
 */
public class Karyawan_Tetap extends Karyawan implements IDapat_gaji {
    private double gajiBulanan;

    public Karyawan_Tetap(String nama, String NIP) {
        super(nama, NIP);
    }
    
    @Override
    public void tampilkanSlipGaji() {
        
        System.out.println("Slip Gaji Karyawan Tetap");
        System.out.println("Nama       : " + getNama());
        System.out.println("NIP        : " + getNIP());
        System.out.println("Status     : Karyawan Tetap");
        System.out.println("Gaji Bulanan: Rp " + gajiBulanan);
        
    }

    
}
