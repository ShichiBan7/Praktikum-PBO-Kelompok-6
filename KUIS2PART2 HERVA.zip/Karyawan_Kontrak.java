/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.kuis_2;

/**
 *
 * @author LENOVO
 */
public class Karyawan_Kontrak extends Karyawan implements IDapat_gaji{
     private double upahHarian;
     private int jumlahHariMasuk;
    
    public Karyawan_Kontrak(String nama, String NIP, double upahHarian, int jumlahHariMasuk) {
        super(nama, NIP);
    }
    
    @Override
    public void tampilkanSlipGaji(){
        double totalGaji = upahHarian * jumlahHariMasuk;
        System.out.println("Slip Gaji Karyawan Kontrak");
        System.out.println("Nama       : " + getNama());
        System.out.println("NIP        : " + getNIP());
        System.out.println("Status     : Karyawan Kontrakl");
        System.out.println("Total gaji: Rp " + totalGaji);
    }
    
    
}
