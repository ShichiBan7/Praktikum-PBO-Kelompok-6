/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.praktikum_8;
import java.awt.Color;
import javax.swing.*;

/**
 *
 * @author LENOVO
 */
public class Praktikum_8 {

    public static void main(String[] args) {
        // Membuat JFrame
        JFrame frame = new JFrame ("Contoh JFrame");
        
        // Mengatur ukuran /set size
        frame.setSize (400, 300);
        
        // Mengatur operasi saat ditutup
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Frame terlihat
        frame.setVisible(true);
        
        // agar muncul di tengah
        frame.setLocationRelativeTo(null);
        
        JLabel label = new JLabel ("Contoh Label",SwingConstants.CENTER);
        
        frame.add(label);
        
        JTextField textField = new JTextField (20);
        frame.add(textField);
        
        JButton button = new JButton ("new JButton");
        frame.add(button);
    }
}
