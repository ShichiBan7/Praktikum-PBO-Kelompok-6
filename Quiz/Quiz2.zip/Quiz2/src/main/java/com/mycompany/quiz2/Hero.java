package com.mycompany.quiz2;

public class Hero extends Character{
    private int mana = 1;
            
    public Hero(String name, int hp, int atk, int def){
        super(name, hp, atk, def);
        this.mana = 1;
    }

    public int getMana() {
        return mana;
    }

    public void setMana(int mana) {
        this.mana = mana;
    }
    
    public void attack(Enemy e){
        int damage = getAtk();
        e.setHp(e.getHp() - damage);
        System.out.println(getName() + " Menyerang " + e.getName() + 
                " dengan damage " + getAtk());
        System.out.println("Sisa hp " + e.getName() + " : " + e.getHp());
        System.out.println();
    }
    
    public void deffend(){
        setHp((getHp() + getDef()));
        System.out.println(getName() + " bertahan, mengurangi damage yang diterima");
        System.out.println();
    }
    
    public void useSkill(Enemy e){
        System.out.println(getName() + " menggunakan skill");
    }
    
    public void tampilkanInfo(){
        System.out.println("Nama Player   : " + getName());
        System.out.println("Hp Player     : " + getHp());
        System.out.println("Attack Damage : " + getAtk());
        System.out.println("Defense       : " + getDef());
        System.out.println();
    }
}
