package com.mycompany.quiz2;

import java.util.Scanner;

public class BattleSystem {
    public static Scanner input = new Scanner(System.in);
    public static String nama;
    public static String pilihRole;
    
    public static void menu(){
        System.out.print("Nama : ");
        nama = input.nextLine();
        System.out.println("Silahkan pilih role : ");
        System.out.println("1. Warrior");
        System.out.println("2. Mage");
        System.out.println("3. Archer");
        System.out.print("Pilihan anda (1-3) : ");
        pilihRole = input.next();
        switch(pilihRole){
            case "1":
                Warrior w1 = new Warrior(nama, 100, 7, 5);
                w1.tampilkanInfo();
                break;
            case "2":
                Mage m1 = new Mage(nama, 100, 10, 1);
                m1.tampilkanInfo();
                break;
            case "3":
                Archer a1 = new Archer(nama, 100, 9, 2);
                a1.tampilkanInfo();
                break;
        }
        
    }
}
