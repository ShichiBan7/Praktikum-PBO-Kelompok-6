package com.mycompany.quiz2;

public class Warrior extends Hero{
    public Warrior(String name, int hp, int atk, int def){
        super(name, hp, atk, def);
    }
    
    @Override
    public void useSkill(Enemy e){
        if(getMana() >= 1){
        int damage = getAtk() * 2;
        e.setHp(e.getHp() - damage);
        setHp(getHp() - 5);
        setMana(getMana() - 1);
        System.out.println(getName() + " menggunakan skill Power Strike, memberikan damage besar!");
        System.out.println(getName() + " menerima recoil damage sebesar 5");
        System.out.println(getName() + " Menyerang " + e.getName() + 
                " dengan damage " + getAtk());
        System.out.println(getName() + " menerima recoil damage sebesar 5");
        System.out.println("Sisa hp " + getName() + " : " + getHp());
        System.out.println("Sisa hp " + e.getName() + " : " + e.getHp());
        System.out.println();
        }else{
            System.out.println("Mana tidak cukup");
        }
    }
    
    @Override
    public void tampilkanInfo(){
        System.out.println("Nama Player   : " + getName());
        System.out.println("Role Player   : Warrior");
        System.out.println("Hp Player     : " + getHp());
        System.out.println("Attack Damage : " + getAtk());
        System.out.println("Defense       : " + getDef());
        System.out.println();
    }
}
