package com.mycompany.quiz2;

public class Quiz2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
