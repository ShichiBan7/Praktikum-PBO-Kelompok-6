package com.mycompany.quiz2;

import java.util.Random;

public class Archer extends Hero{
    public Archer(String name, int hp, int atk, int def){
        super(name, hp, atk, def);
    }
    
    @Override
    public void useSkill(Enemy e){
        if(getMana() >= 1){
        Random random = new Random();
        double range = random.nextDouble(1.1,1.25);
        setMana(getMana() - 1);
        System.out.println(getName() + " menggunakan skill Double Shot, memberikan damage besar!");
        for(int i = 1; i <= 2; i++){
            int damage = getAtk() * 2;
            damage *= range;
            System.out.println("Memberikan " + damage + " damage pada hit ke-" + i);
            e.setHp(e.getHp() - damage);
        }
        System.out.println("Sisa hp " + e.getName() + " : " + e.getHp());
        System.out.println();
        }else{
            System.out.println("Mana tidak cukup");
        }
    }
    
    @Override
    public void tampilkanInfo(){
        System.out.println("Nama Player   : " + getName());
        System.out.println("Role Player   : Archer");
        System.out.println("Hp Player     : " + getHp());
        System.out.println("Attack Damage : " + getAtk());
        System.out.println("Defense       : " + getDef());
        System.out.println();
    }
}
