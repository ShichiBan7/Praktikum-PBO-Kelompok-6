package com.mycompany.quiz2;

public interface Attackable {
    public void attack();
    public void takeDamage();
}
