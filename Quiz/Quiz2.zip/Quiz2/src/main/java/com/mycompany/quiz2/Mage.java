package com.mycompany.quiz2;

public class Mage extends Hero{
    public Mage(String name, int hp, int atk, int def){
        super(name, hp, atk, def);
    }
    
    @Override
    public void useSkill(Enemy e){
        if(getMana() >= 1){
            if(chance < 30){
        int damage = getAtk() * 3;
        e.setHp(e.getHp() - damage);
        setMana(getMana() - 1);
        System.out.println(getName() + " menggunakan skill Fire Ball, memberikan damage besar!");
        System.out.println(getName() + " Menyerang " + e.getName() + 
                " dengan damage " + getAtk());
        System.out.println("Sisa hp " + e.getName() + " : " + e.getHp());
        System.out.println();
            }else{
                System.out.println(getName() + " gagal mengeluarkan skill");
            }
        }else{
            System.out.println("Mana tidak cukup");
        }
    }
    
    @Override
    public void tampilkanInfo(){
        System.out.println("Nama Player   : " + getName());
        System.out.println("Role Player   : Mage");
        System.out.println("Hp Player     : " + getHp());
        System.out.println("Attack Damage : " + getAtk());
        System.out.println("Defense       : " + getDef());
        System.out.println();
    }
}
