package com.mycompany.quiz2;

public class Enemy extends Character{
    public Enemy(String name, int hp, int atk, int def){
        super(name, hp, atk, def);
    }
    
    public void attack(Hero h){
        int damage = getAtk();
        setHp(getHp() - damage);
        System.out.println(getName() + " Menyerang " + h.getName() + 
                " dengan damage " + getAtk());
        System.out.println("Sisa hp " + h.getName() + " : " + h.getHp());
        System.out.println();
    }
}
