package com.mycompany.quiz2;

import java.util.Random;

public class Main {
    public static void main(String[] args){
        Random random = new Random();
        BattleSystem.menu();
    }
}
