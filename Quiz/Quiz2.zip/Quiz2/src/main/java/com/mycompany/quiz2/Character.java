package com.mycompany.quiz2;

import java.util.Random;

public class Character {
    Random random = new Random();
    public int chance = random.nextInt(100);
    private String name;
    private int hp;
    private int atk;
    private int def;
    
    public Character(String name, int hp, int atk, int def){
        this.name = name;
        this.hp = hp;
        this.atk = atk;
        this.def = def;
    }

    public String getName() {
        return name;
    }

    public int getHp() {
        return hp;
    }

    public int getAtk() {
        return atk;
    }

    public int getDef() {
        return def;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public void setAtk(int atk) {
        this.atk = atk;
    }

    public void setDef(int def) {
        this.def = def;
    }
    
    
}
