package com.mycompany.requiz2;

public class DemoHRD {
    public static void main(String[] args){
        IDapatGaji[] daftarGaji = new IDapatGaji[2];
        KaryawanTetap kt1 = new KaryawanTetap("Nopal", "1234567", 7000000);
        KaryawanKontrak kk1 = new KaryawanKontrak("Ado", "98765", 1000000, 5);
        daftarGaji[0] = kt1;
        daftarGaji[1] = kk1;
        
        for(int i = 0; i < 2; i++){
            daftarGaji[i].tampilkanSlipGaji();
        }
    }
}
