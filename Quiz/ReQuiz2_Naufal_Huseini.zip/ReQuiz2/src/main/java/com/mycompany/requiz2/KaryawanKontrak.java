package com.mycompany.requiz2;

public class KaryawanKontrak extends Karyawan implements IDapatGaji{
    private double upahHarian;
    private double jumlahHariMasuk;
    
    public KaryawanKontrak(String nama, String NIP, double upahHarian, double jumlahHariMasuk){
        super(nama, NIP);
        this.upahHarian = upahHarian;
        this.jumlahHariMasuk = jumlahHariMasuk;
    }

    public double getUpahHarian() {
        return upahHarian;
    }

    public double getJumlahHariMasuk() {
        return jumlahHariMasuk;
    }

    public void setUpahHarian(double upahHarian) {
        this.upahHarian = upahHarian;
    }

    public void setJumlahHariMasuk(double jumlahHariMasuk) {
        this.jumlahHariMasuk = jumlahHariMasuk;
    }
    
    
    
    @Override
    public void tampilkanSlipGaji(){
        System.out.println("Nama Karyawan : " + getNama());
        System.out.println("NIP           : " + getNIP());
        System.out.println("Status        : Karyawan Kontrak");
        System.out.println("Total Gaji    : " + (getUpahHarian() * getJumlahHariMasuk()));
        System.out.println();
    }
}
