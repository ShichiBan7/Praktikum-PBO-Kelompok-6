package com.mycompany.requiz2;

public class ReQuiz2 {

    public static void main(String[] args) {
        
    }
}
