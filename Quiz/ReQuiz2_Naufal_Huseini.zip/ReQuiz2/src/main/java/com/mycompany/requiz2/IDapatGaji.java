package com.mycompany.requiz2;

public interface IDapatGaji {
    public void tampilkanSlipGaji();
}
